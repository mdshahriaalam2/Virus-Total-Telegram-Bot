const { loggerMiddleware } = require('../utils/logger');

function setupMiddleware(bot) {
    // Add logging middleware
    bot.use(loggerMiddleware);

    // Add error handling middleware
    bot.use(async (ctx, next) => {
        try {
            await next();
        } catch (error) {
            console.error('Middleware error:', error);
            return ctx.reply('An error occurred while processing your request.');
        }
    });

    // Add user tracking middleware
    bot.use(async (ctx, next) => {
        if (ctx.from) {
            const { trackUser } = require('../database');
            await trackUser(ctx.from);
        }
        return next();
    });

    // Add response time middleware
    bot.use(async (ctx, next) => {
        const start = Date.now();
        await next();
        const ms = Date.now() - start;
        
        if (ctx.message?.text?.startsWith('/')) {
            await ctx.reply(`Command processed in ${ms}ms`);
        }
    });
}

module.exports = {
    setupMiddleware
}; 