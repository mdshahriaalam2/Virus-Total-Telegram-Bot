const Bottleneck = require('bottleneck');

// In-memory store for rate limits
const userLimits = new Map();

function createRateLimiter() {
    const maxScansPerHour = parseInt(process.env.MAX_SCANS_PER_HOUR) || 5;
    const hourInMs = 60 * 60 * 1000;

    return {
        async tryAcquire(userId) {
            const now = Date.now();
            const userLimit = userLimits.get(userId) || { count: 0, resetTime: now + hourInMs };

            // Reset counter if time window has passed
            if (now >= userLimit.resetTime) {
                userLimit.count = 0;
                userLimit.resetTime = now + hourInMs;
            }

            // Check if limit is reached
            if (userLimit.count >= maxScansPerHour) {
                return false;
            }

            // Increment counter and update
            userLimit.count++;
            userLimits.set(userId, userLimit);
            return true;
        },

        getRemainingScans(userId) {
            const userLimit = userLimits.get(userId);
            if (!userLimit) {
                return maxScansPerHour;
            }

            const now = Date.now();
            if (now >= userLimit.resetTime) {
                return maxScansPerHour;
            }

            return Math.max(0, maxScansPerHour - userLimit.count);
        },

        getResetTime(userId) {
            const userLimit = userLimits.get(userId);
            if (!userLimit) {
                return Date.now() + hourInMs;
            }
            return userLimit.resetTime;
        }
    };
}

module.exports = {
    createRateLimiter
}; 