const axios = require('axios');
const fs = require('fs').promises;
const path = require('path');
const crypto = require('crypto');
const { OpenAI } = require('openai');
const { createRateLimiter } = require('../middleware/rateLimiter');
const { logger } = require('../utils/logger');
const { scanQueue } = require('../queues/scanQueue');
const { saveToDatabase } = require('../database');

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const MAX_FILE_SIZE = parseInt(process.env.MAX_FILE_SIZE) || 100 * 1024 * 1024; // 100MB

async function calculateFileHash(filePath) {
    const fileBuffer = await fs.readFile(filePath);
    return crypto.createHash('sha256').update(fileBuffer).digest('hex');
}

async function analyzeWithAI(fileInfo, scanResults) {
    try {
        const prompt = `Analyze this file and provide security insights:
            File name: ${fileInfo.name}
            Size: ${fileInfo.size} bytes
            Type: ${fileInfo.mimeType}
            VirusTotal detections: ${scanResults.positives}/${scanResults.total}
            
            Please provide:
            1. Risk assessment
            2. Potential threats
            3. Recommendations`;

        const completion = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [{ role: "user", content: prompt }],
            temperature: 0.7,
            max_tokens: 500
        });

        return completion.choices[0].message.content;
    } catch (error) {
        logger.error('AI analysis error:', error);
        return 'AI analysis unavailable at the moment.';
    }
}

async function scanWithVirusTotal(filePath, fileHash) {
    const apiKey = process.env.VIRUSTOTAL_API_KEY;
    
    try {
        // First, check if the file has been scanned before
        const checkUrl = `https://www.virustotal.com/vtapi/v2/file/report?apikey=${apiKey}&resource=${fileHash}`;
        const checkResponse = await axios.get(checkUrl);
        
        if (checkResponse.data.response_code === 1) {
            return checkResponse.data;
        }

        // If not scanned before, upload and scan
        const formData = new FormData();
        formData.append('file', await fs.readFile(filePath));
        
        const uploadResponse = await axios.post(
            `https://www.virustotal.com/vtapi/v2/file/scan`,
            formData,
            {
                headers: {
                    'apikey': apiKey,
                    ...formData.getHeaders()
                }
            }
        );

        // Poll for results
        const scanId = uploadResponse.data.scan_id;
        let attempts = 0;
        while (attempts < 10) {
            await new Promise(resolve => setTimeout(resolve, 15000)); // Wait 15 seconds
            const resultResponse = await axios.get(
                `https://www.virustotal.com/vtapi/v2/file/report?apikey=${apiKey}&resource=${scanId}`
            );
            
            if (resultResponse.data.response_code === 1) {
                return resultResponse.data;
            }
            attempts++;
        }
        
        throw new Error('Scan timeout');
    } catch (error) {
        logger.error('VirusTotal scan error:', error);
        throw error;
    }
}

function setupFileHandlers(bot) {
    const rateLimiter = createRateLimiter();

    bot.on(['document', 'photo', 'video', 'audio'], async (ctx) => {
        try {
            // Apply rate limiting
            if (!await rateLimiter.tryAcquire(ctx.from.id)) {
                return ctx.reply('Rate limit exceeded. Please try again later.');
            }

            const file = ctx.message.document || ctx.message.photo?.[0] || ctx.message.video || ctx.message.audio;
            if (!file) {
                return ctx.reply('No file detected.');
            }

            if (file.file_size > MAX_FILE_SIZE) {
                return ctx.reply(`File too large. Maximum size is ${MAX_FILE_SIZE / 1024 / 1024}MB`);
            }

            const statusMessage = await ctx.reply('⏳ Processing file...');

            // Download file
            const filePath = path.join(process.env.UPLOAD_DIR, `${file.file_id}`);
            await ctx.telegram.downloadFile(file.file_id, filePath);

            // Calculate file hash
            const fileHash = await calculateFileHash(filePath);

            // Add to scan queue
            await scanQueue.add('scan', {
                filePath,
                fileHash,
                userId: ctx.from.id,
                messageId: statusMessage.message_id,
                chatId: ctx.chat.id,
                fileInfo: {
                    name: file.file_name || 'unnamed',
                    size: file.file_size,
                    mimeType: file.mime_type
                }
            });

            await ctx.telegram.editMessageText(
                ctx.chat.id,
                statusMessage.message_id,
                null,
                '🔍 File queued for scanning...'
            );

        } catch (error) {
            logger.error('File handling error:', error);
            await ctx.reply('An error occurred while processing the file.');
        }
    });
}

module.exports = {
    setupFileHandlers,
    scanWithVirusTotal,
    analyzeWithAI,
    calculateFileHash
}; 