const { getStats } = require('../database');
const { logger } = require('../utils/logger');

// List of admin user IDs
const ADMIN_IDS = process.env.ADMIN_CHAT_ID ? process.env.ADMIN_CHAT_ID.split(',').map(Number) : [];

// Admin middleware
function isAdmin(ctx, next) {
    if (!ADMIN_IDS.includes(ctx.from?.id)) {
        return ctx.reply('⛔ This command is only available to administrators.');
    }
    return next();
}

function setupAdminHandlers(bot) {
    // Admin stats command with more detailed information
    bot.command('admin_stats', isAdmin, async (ctx) => {
        try {
            const stats = await getStats();
            const uptime = process.uptime();
            const memory = process.memoryUsage();

            const message = `
📊 Detailed Statistics Report
━━━━━━━━━━━━━━━━━━━━━━

🔍 Scan Statistics:
• Total Scans: ${stats.total_scans}
• Malicious Files: ${stats.malicious_files}
• Clean Files: ${stats.total_scans - stats.malicious_files}
• Detection Rate: ${((stats.malicious_files / stats.total_scans) * 100).toFixed(2)}%
• Unique Users: ${stats.unique_users}

⚙️ System Status:
• Uptime: ${formatUptime(uptime)}
• Memory Usage:
  - RSS: ${formatBytes(memory.rss)}
  - Heap Total: ${formatBytes(memory.heapTotal)}
  - Heap Used: ${formatBytes(memory.heapUsed)}
  - External: ${formatBytes(memory.external)}

Generated at: ${new Date().toISOString()}
`;

            return ctx.reply(message);
        } catch (error) {
            logger.error('Admin stats error:', error);
            return ctx.reply('Failed to fetch admin statistics.');
        }
    });

    // Clear quarantine command
    bot.command('clear_quarantine', isAdmin, async (ctx) => {
        try {
            const fs = require('fs').promises;
            const path = require('path');
            
            const quarantineDir = process.env.QUARANTINE_DIR || path.join(__dirname, '../../quarantine');
            const files = await fs.readdir(quarantineDir);
            
            for (const file of files) {
                await fs.unlink(path.join(quarantineDir, file));
            }

            logger.info(`Quarantine cleared: ${files.length} files removed`);
            return ctx.reply(`✅ Quarantine cleared: ${files.length} files removed`);
        } catch (error) {
            logger.error('Clear quarantine error:', error);
            return ctx.reply('Failed to clear quarantine directory.');
        }
    });

    // Broadcast message to all users
    bot.command('broadcast', isAdmin, async (ctx) => {
        const message = ctx.message.text.split('/broadcast ')[1];
        
        if (!message) {
            return ctx.reply('Please provide a message to broadcast.');
        }

        try {
            const { getAllUserIds } = require('../database');
            const userIds = await getAllUserIds();
            let sent = 0;
            let failed = 0;

            for (const userId of userIds) {
                try {
                    await bot.telegram.sendMessage(userId, `📢 Broadcast Message:\n\n${message}`);
                    sent++;
                } catch (error) {
                    failed++;
                    logger.error(`Failed to send broadcast to user ${userId}:`, error);
                }
                // Add delay to avoid hitting rate limits
                await new Promise(resolve => setTimeout(resolve, 50));
            }

            return ctx.reply(
                `📢 Broadcast completed:\n` +
                `• Sent: ${sent}\n` +
                `• Failed: ${failed}\n` +
                `• Total users: ${userIds.length}`
            );
        } catch (error) {
            logger.error('Broadcast error:', error);
            return ctx.reply('Failed to send broadcast message.');
        }
    });
}

// Helper functions
function formatUptime(seconds) {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    return `${days}d ${hours}h ${minutes}m ${secs}s`;
}

function formatBytes(bytes) {
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unit = 0;

    while (size >= 1024 && unit < units.length - 1) {
        size /= 1024;
        unit++;
    }

    return `${size.toFixed(2)} ${units[unit]}`;
}

module.exports = {
    setupAdminHandlers,
    isAdmin
}; 