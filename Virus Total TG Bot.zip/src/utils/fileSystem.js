const fs = require('fs').promises;
const path = require('path');
const { logger } = require('./logger');

async function initializeDirectories() {
    const dirs = [
        process.env.UPLOAD_DIR || path.join(__dirname, '../../uploads'),
        process.env.QUARANTINE_DIR || path.join(__dirname, '../../quarantine'),
        path.join(__dirname, '../../logs'),
        path.join(__dirname, '../../data')
    ];

    for (const dir of dirs) {
        try {
            await fs.mkdir(dir, { recursive: true });
            logger.info(`Directory created/verified: ${dir}`);
        } catch (error) {
            logger.error(`Failed to create directory: ${dir}`, error);
            throw error;
        }
    }
}

async function cleanupOldFiles(directory, maxAgeHours = 24) {
    try {
        const files = await fs.readdir(directory);
        const now = Date.now();
        const maxAge = maxAgeHours * 60 * 60 * 1000;

        for (const file of files) {
            const filePath = path.join(directory, file);
            const stats = await fs.stat(filePath);

            if (now - stats.mtime.getTime() > maxAge) {
                await fs.unlink(filePath);
                logger.info(`Cleaned up old file: ${filePath}`);
            }
        }
    } catch (error) {
        logger.error('File cleanup error:', error);
    }
}

// Schedule cleanup every 6 hours
setInterval(() => {
    const uploadDir = process.env.UPLOAD_DIR || path.join(__dirname, '../../uploads');
    cleanupOldFiles(uploadDir);
}, 6 * 60 * 60 * 1000);

module.exports = {
    initializeDirectories,
    cleanupOldFiles
}; 