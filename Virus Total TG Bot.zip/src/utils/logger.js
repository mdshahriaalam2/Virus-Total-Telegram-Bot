const winston = require('winston');
const path = require('path');

const logLevels = {
    error: 0,
    warn: 1,
    info: 2,
    debug: 3
};

const logger = winston.createLogger({
    levels: logLevels,
    level: process.env.LOG_LEVEL || 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json()
    ),
    transports: [
        // Console transport
        new winston.transports.Console({
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.simple()
            )
        }),
        // File transport
        new winston.transports.File({
            filename: process.env.LOG_FILE || path.join(__dirname, '../../logs/app.log'),
            maxsize: 5242880, // 5MB
            maxFiles: 5,
            tailable: true
        })
    ]
});

// Add request logging middleware
function loggerMiddleware(ctx, next) {
    const start = Date.now();
    return next().then(() => {
        const ms = Date.now() - start;
        logger.info('Request processed', {
            method: ctx.updateType || ctx.message?.text,
            userId: ctx.from?.id,
            duration: `${ms}ms`
        });
    });
}

module.exports = {
    logger,
    loggerMiddleware
}; 