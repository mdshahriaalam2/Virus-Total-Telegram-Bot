const Queue = require('bull');
const path = require('path');
const fs = require('fs').promises;
const { scanWithVirusTotal, analyzeWithAI } = require('../handlers/fileHandlers');
const { logger } = require('../utils/logger');
const { saveToDatabase } = require('../database');

// Create Redis connection
const redisConfig = {
    redis: process.env.REDIS_URL
};

// Create scan queue
const scanQueue = new Queue('file-scan', redisConfig);

// Process scan jobs
scanQueue.process('scan', async (job) => {
    const { filePath, fileHash, userId, messageId, chatId, fileInfo } = job.data;
    const bot = global.bot; // Access the bot instance

    try {
        // Update status
        await bot.telegram.editMessageText(
            chatId,
            messageId,
            null,
            '🔍 Scanning file with VirusTotal...'
        );

        // Scan with VirusTotal
        const scanResults = await scanWithVirusTotal(filePath, fileHash);

        // Get AI analysis
        await bot.telegram.editMessageText(
            chatId,
            messageId,
            null,
            '🤖 Analyzing results with AI...'
        );
        
        const aiAnalysis = await analyzeWithAI(fileInfo, scanResults);

        // Prepare result message
        const resultMessage = formatResults(fileInfo, scanResults, aiAnalysis);

        // Save results to database
        await saveToDatabase({
            userId,
            fileHash,
            fileName: fileInfo.name,
            scanResults,
            aiAnalysis,
            timestamp: new Date()
        });

        // Handle quarantine if needed
        if (scanResults.positives > 0) {
            const quarantinePath = path.join(process.env.QUARANTINE_DIR, fileHash);
            await fs.rename(filePath, quarantinePath);
            
            // Notify admin
            if (process.env.ADMIN_CHAT_ID) {
                await bot.telegram.sendMessage(
                    process.env.ADMIN_CHAT_ID,
                    `⚠️ Malicious file detected!\nUser: ${userId}\nFile: ${fileInfo.name}\nDetections: ${scanResults.positives}/${scanResults.total}`
                );
            }
        } else {
            // Clean up file if safe
            await fs.unlink(filePath);
        }

        // Send final results
        await bot.telegram.editMessageText(
            chatId,
            messageId,
            null,
            resultMessage,
            { parse_mode: 'HTML', disable_web_page_preview: true }
        );

    } catch (error) {
        logger.error('Scan job error:', error);
        
        // Notify user of error
        await bot.telegram.editMessageText(
            chatId,
            messageId,
            null,
            '❌ An error occurred while scanning the file. Please try again later.'
        );

        // Clean up file
        try {
            await fs.unlink(filePath);
        } catch (unlinkError) {
            logger.error('File cleanup error:', unlinkError);
        }
    }
});

function formatResults(fileInfo, scanResults, aiAnalysis) {
    const detectionRate = (scanResults.positives / scanResults.total * 100).toFixed(1);
    
    return `
📝 File Analysis Report
━━━━━━━━━━━━━━━━━━

📄 File Information:
• Name: ${fileInfo.name}
• Size: ${(fileInfo.size / 1024).toFixed(2)} KB
• Type: ${fileInfo.mimeType}
• Hash: ${scanResults.sha256}

🔍 Scan Results:
• Detection Rate: ${scanResults.positives}/${scanResults.total} (${detectionRate}%)
• Status: ${scanResults.positives > 0 ? '⚠️ SUSPICIOUS' : '✅ SAFE'}

🤖 AI Analysis:
${aiAnalysis}

🔗 VirusTotal Link:
${scanResults.permalink}
`;
}

// Handle failed jobs
scanQueue.on('failed', (job, err) => {
    logger.error('Queue job failed:', {
        jobId: job.id,
        error: err.message
    });
});

module.exports = {
    scanQueue
}; 