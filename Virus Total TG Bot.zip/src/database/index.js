const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');
const { logger } = require('../utils/logger');

let db;

async function setupDatabase() {
    const dbPath = process.env.SQLITE_PATH || path.join(__dirname, '../../data/database.sqlite');

    try {
        db = await open({
            filename: dbPath,
            driver: sqlite3.Database
        });

        // Create tables if they don't exist
        await db.exec(`
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                file_hash TEXT NOT NULL,
                file_name TEXT NOT NULL,
                scan_results TEXT NOT NULL,
                ai_analysis TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                is_malicious BOOLEAN NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_user_id ON scans(user_id);
            CREATE INDEX IF NOT EXISTS idx_file_hash ON scans(file_hash);
            CREATE INDEX IF NOT EXISTS idx_timestamp ON scans(timestamp);
        `);

        logger.info('Database setup completed');
    } catch (error) {
        logger.error('Database setup error:', error);
        throw error;
    }
}

async function saveToDatabase(data) {
    try {
        const {
            userId,
            fileHash,
            fileName,
            scanResults,
            aiAnalysis,
            timestamp
        } = data;

        await db.run(
            `INSERT INTO scans (
                user_id,
                file_hash,
                file_name,
                scan_results,
                ai_analysis,
                timestamp,
                is_malicious
            ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [
                userId,
                fileHash,
                fileName,
                JSON.stringify(scanResults),
                aiAnalysis,
                timestamp.toISOString(),
                scanResults.positives > 0
            ]
        );
    } catch (error) {
        logger.error('Database save error:', error);
        throw error;
    }
}

async function getUserHistory(userId, limit = 10) {
    try {
        return await db.all(
            `SELECT * FROM scans 
             WHERE user_id = ? 
             ORDER BY timestamp DESC 
             LIMIT ?`,
            [userId, limit]
        );
    } catch (error) {
        logger.error('Database query error:', error);
        throw error;
    }
}

async function getFileByHash(fileHash) {
    try {
        return await db.get(
            'SELECT * FROM scans WHERE file_hash = ? ORDER BY timestamp DESC LIMIT 1',
            [fileHash]
        );
    } catch (error) {
        logger.error('Database query error:', error);
        throw error;
    }
}

async function getStats() {
    try {
        const stats = await db.get(`
            SELECT 
                COUNT(*) as total_scans,
                SUM(CASE WHEN is_malicious THEN 1 ELSE 0 END) as malicious_files,
                COUNT(DISTINCT user_id) as unique_users
            FROM scans
        `);

        return stats;
    } catch (error) {
        logger.error('Database stats error:', error);
        throw error;
    }
}

module.exports = {
    setupDatabase,
    saveToDatabase,
    getUserHistory,
    getFileByHash,
    getStats
}; 