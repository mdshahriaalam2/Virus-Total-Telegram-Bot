require('dotenv').config();
const { Telegraf } = require('telegraf');
const { setupCommands } = require('./commands');
const { setupMiddleware } = require('./middleware');
const { setupDatabase } = require('./database');
const { setupLocalization } = require('./localization');
const { setupFileHandlers } = require('./handlers/fileHandlers');
const { setupAdminHandlers } = require('./handlers/adminHandlers');
const { logger } = require('./utils/logger');
const { initializeDirectories } = require('./utils/fileSystem');

// Initialize the bot
const bot = new Telegraf(process.env.BOT_TOKEN);

async function startBot() {
    try {
        // Initialize required directories
        await initializeDirectories();

        // Setup database
        await setupDatabase();

        // Setup middleware (rate limiting, auth, etc.)
        setupMiddleware(bot);

        // Setup localization
        setupLocalization(bot);

        // Register command handlers
        setupCommands(bot);

        // Register file handling
        setupFileHandlers(bot);

        // Register admin handlers
        setupAdminHandlers(bot);

        // Error handling
        bot.catch((err, ctx) => {
            logger.error('Bot error:', err);
            ctx.reply('An error occurred while processing your request. Please try again later.');
        });

        // Start the bot
        await bot.launch();
        logger.info('Bot started successfully');

        // Enable graceful stop
        process.once('SIGINT', () => bot.stop('SIGINT'));
        process.once('SIGTERM', () => bot.stop('SIGTERM'));
    } catch (error) {
        logger.error('Failed to start bot:', error);
        process.exit(1);
    }
}

startBot(); 