const { getUserHistory, getStats } = require('../database');
const { createRateLimiter } = require('../middleware/rateLimiter');

function setupCommands(bot) {
    const rateLimiter = createRateLimiter();

    // Start command
    bot.command('start', (ctx) => {
        return ctx.reply(
            'Welcome to the File Scanner Bot! 🔍\n\n' +
            'I can help you scan files for malware and provide AI-powered analysis.\n\n' +
            'Simply send me any file (up to 100MB) and I\'ll scan it for you.\n\n' +
            'Use /help to see all available commands.'
        );
    });

    // Help command
    bot.command('help', (ctx) => {
        return ctx.reply(
            '🤖 Available Commands:\n\n' +
            '/scan - Send a file to scan it\n' +
            '/status - Check your remaining scans\n' +
            '/history - View your scan history\n' +
            '/stats - View global statistics\n' +
            '/help - Show this help message\n\n' +
            '📝 Usage Tips:\n' +
            '• Maximum file size: 100MB\n' +
            '• Supported files: documents, images, videos, audio\n' +
            '• Rate limit: 5 scans per hour\n\n' +
            '⚠️ Note: Never share sensitive or personal files!'
        );
    });

    // Status command
    bot.command('status', async (ctx) => {
        const remaining = rateLimiter.getRemainingScans(ctx.from.id);
        const resetTime = new Date(rateLimiter.getResetTime(ctx.from.id));

        return ctx.reply(
            `📊 Your Scan Status:\n\n` +
            `• Remaining scans: ${remaining}\n` +
            `• Reset time: ${resetTime.toLocaleString()}\n\n` +
            `Rate limit: 5 scans per hour`
        );
    });

    // History command
    bot.command('history', async (ctx) => {
        try {
            const history = await getUserHistory(ctx.from.id);
            
            if (!history.length) {
                return ctx.reply('You haven\'t scanned any files yet.');
            }

            let message = '📜 Your Recent Scans:\n\n';
            
            for (const scan of history) {
                const scanData = JSON.parse(scan.scan_results);
                const status = scan.is_malicious ? '⚠️ SUSPICIOUS' : '✅ SAFE';
                
                message += `${status} | ${scan.file_name}\n` +
                          `📅 ${new Date(scan.timestamp).toLocaleString()}\n` +
                          `🔍 Detections: ${scanData.positives}/${scanData.total}\n\n`;
            }

            return ctx.reply(message);
        } catch (error) {
            return ctx.reply('Failed to fetch scan history. Please try again later.');
        }
    });

    // Stats command
    bot.command('stats', async (ctx) => {
        try {
            const stats = await getStats();
            
            return ctx.reply(
                `📊 Global Statistics:\n\n` +
                `• Total scans: ${stats.total_scans}\n` +
                `• Malicious files detected: ${stats.malicious_files}\n` +
                `• Unique users: ${stats.unique_users}\n\n` +
                `Stay safe! 🛡️`
            );
        } catch (error) {
            return ctx.reply('Failed to fetch statistics. Please try again later.');
        }
    });

    // Register commands with Telegram
    bot.telegram.setMyCommands([
        { command: 'scan', description: 'Scan an uploaded file for malware' },
        { command: 'status', description: 'View current scan queue status' },
        { command: 'history', description: 'Show your scan history' },
        { command: 'stats', description: 'View global statistics' },
        { command: 'help', description: 'List available commands' }
    ]).catch(error => {
        console.error('Failed to set commands:', error);
    });
}

module.exports = {
    setupCommands
}; 